
from setuptools import setup , find_packages

setup(
    name='movie_rental',
    version='1.0.0',
    description='A library for managing movie rentals',
    author='Salem Inc',
    packages=find_packages(),
)
